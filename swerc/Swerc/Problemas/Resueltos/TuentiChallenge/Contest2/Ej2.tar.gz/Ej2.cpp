#include <iostream>
using namespace std;

//Typedef
typedef long long int llint;

//Funciones variopintas
int numCifra();
llint exponenciacion(int n);
int numUnos(llint N);
void solve();

//Variables globales
int M;
llint N;

//MAIN
int main()
{
	int C;
	cin>>C;
	for(int i=1; i<=C; i++)
	{
		solve();
		cout<<"Case #"<<i<<": "<<M<<endl;
	}
	return 0;
}

int numCifra()
{
	llint N2=N;
	int cifras=0;

	while(N2!=0)
	{
		N2/=2;
		cifras++;
	}
	return cifras;
}
llint exponenciacion(int n)
{
	llint result=1;

	for(int i=0; i<n; i++)
	{
		result+=result;
	}
	return result;
}

int numUnos(llint N)
{
	llint N2=N;

	int unos=0;

	while(N2!=0)
	{
		if(N2%2==1)
		{
			unos++;
			N2/=2;
		}
		else
		{
			N2/=2;
		}
	}

	return unos;
}

void solve()
{
	cin>>N;

	int nc=numCifra();
	llint x=exponenciacion(nc-1)-1;

	M=nc-1+numUnos(N-x);
}
